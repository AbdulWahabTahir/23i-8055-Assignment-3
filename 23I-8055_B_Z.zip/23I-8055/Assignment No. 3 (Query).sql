ALTER TABLE dbo.teams$
ADD FOREIGN KEY (HOME_STADIUM_ID) REFERENCES stadiums$(S_ID);

ALTER TABLE managers$
ADD FOREIGN KEY (TEAM_ID) REFERENCES teams$(T_ID); 

ALTER TABLE matches$
ADD FOREIGN KEY (STADIUM_ID) REFERENCES stadiums$(S_ID);

ALTER TABLE goals$
ADD FOREIGN KEY (MATCH_ID) REFERENCES MATCHES$(MATCH_ID);

ALTER TABLE goals$
ADD FOREIGN KEY (PID) REFERENCES PLAYERS$ (PLAYER_ID);

--Question No. 1
--SELECT table1.column1, table2.column2
--FROM table1
--RIGHT JOIN table2 ON table1.column1 = table2.column1;

--QUESTION NO. 1
--All the players that have played under a specific manager.
SELECT ply.PLAYER_ID, ply.JERSEY_NUMBER, ply.POSITION
FROM players_attributes$ ply
JOIN teams$ T ON ply.TEAM_ID = T.T_ID
JOIN managers$ mgr ON T.T_ID = mgr.M_ID
WHERE mgr.M_ID = 1;

--Question No. 2
--All the matches that have been played in a specific country.
SELECT st.NAME, st.CITY, st.COUNTRY, st.CAPACITY
FROM stadiums$ st
JOIN matches$ MT ON MT.STADIUM_ID = st.S_ID
WHERE st.S_ID = 1;

--Question No. 3
-- All the teams that have won more than 3 matches in their home stadium.
SELECT T.T_ID, T.TEAM_NAME
FROM (
	SELECT T.T_ID, COUNT(*) as wins
	FROM matches$ MT
	JOIN teams$ T on MT.HOME_TEAM_SCORE > MT.AWAY_TEAM_SCORE AND MT.STADIUM_ID = t.HOME_STADIUM_ID
	Group BY T.T_ID
	HAVING COUNT (*) > 3
)	AS WIN_COUNT
JOIN teams$ T ON WIN_COUNT.T_ID = T.T_ID;

--Question No. 4
--All the teams with foreign managers.
SELECT MT.M_ID, MT.FIRST_NAME, MT.LAST_NAME, MT.NATIONALITY, T.TEAM_NAME,T.COUNTRY
FROM managers$ MT
JOIN teams$ T ON MT.M_ID = T.T_ID
WHERE T.COUNTRY <> MT.NATIONALITY;

--Question No. 5
--All the matches that were played in stadiums with seating capacity greater than 60,000.
SELECT ST.NAME ,MS.ATTENDANCE
FROM stadiums$ ST
JOIN matches$ MT ON MT.STADIUM_ID = ST.S_ID
JOIN matches_summary$ MS ON MT.MATCH_ID = MS.MATCH_ID
WHERE MS.ATTENDANCE > 60000;

--Question No. 6
--All Goals made without an assist in 2020 by players having height greater than 180 cm.
SELECT P.PLAYER_ID, FIRST_NAME, P.LAST_NAME, PA.HEIGHT, MT.SEASON
FROM goals$ GL
JOIN players_attributes$ PA ON GL.PID = PA.PLAYER_ID
JOIN players$ P ON P.PLAYER_ID = PA.PLAYER_ID
JOIN matches$ MT ON GL.MATCH_ID = MT.MATCH_ID
WHERE GL.ASSIST IS NULL AND PA.HEIGHT > 180 AND MT.SEASON = '2020-2021';


--Question No. 7
-- All Russian teams with win percentage less than 50% in home matches.
SELECT DISTINCT MS.HOME_TEAM_ID, T.T_ID, T.TEAM_NAME, T.COUNTRY
FROM matches_summary$ MS
JOIN matches$ M ON M.MATCH_ID = MS.MATCH_ID
JOIN stadiums$ S ON S.S_ID = M.STADIUM_ID
JOIN teams$ T ON T.HOME_STADIUM_ID = S.S_ID
WHERE T.COUNTRY = 'Russia';

--Question No. 8
--All Stadiums that have hosted more than 6 matches with host team having a win percentage less than 50%.

SELECT  S.NAME, COUNT(*) AS TOTAL_Matches
FROM stadiums$ S
JOIN matches$ M ON M.STADIUM_ID = S.S_ID
AND M.HOME_TEAM_SCORE < M.AWAY_TEAM_SCORE
GROUP BY S.NAME
HAVING COUNT(*) > 6;

--Question No. 9
--The season with the greatest number of left-foot goals.
Select TOP 1 M.SEASON,COUNT (*) AS Left_Foot
FROM matches$ M
JOIN goals$ GL ON M.MATCH_ID = GL.MATCH_ID
WHERE GL.GOAL_DESC = 'left-footed shot'
GROUP BY M.SEASON
ORDER BY Left_Foot DESC;


--Question No. 10
--The country with maximum number of players with at least one goal.
SELECT TOP 1 P.NATIONALITY, COUNT(*) AS Player_Count
FROM players$ P
JOIN goals$ GL ON P.PLAYER_ID = GL.PID
GROUP BY P.NATIONALITY
ORDER BY Player_Count DESC;

--Question No. 11
--All the stadiums with greater number of left-footed shots than right-footed shots.
SELECT S.S_ID, S.NAME, S.CITY, S.COUNTRY, S.CAPACITY
FROM goals$ GL
JOIN matches$ M ON GL.MATCH_ID = M.MATCH_ID
JOIN stadiums$ S ON S.S_ID = M.STADIUM_ID
GROUP BY S.S_ID, S.NAME, S.CITY, S.COUNTRY, S.CAPACITY
HAVING SUM (CASE WHEN GL.GOAL_DESC = 'Left-footed shot' THEN 1 ELSE 0 END) > SUM (CASE WHEN GL.GOAL_DESC = 'right-footed shot' THEN 1 ELSE 0 END);

--Question No. 12
--All matches that were played in country with maximum cumulative stadium seating capacity order by recent first.
SELECT S.S_ID, S.NAME, S.CITY, S.COUNTRY, SUM(S.CAPACITY) AS Total_attendance
FROM matches_summary$ MS
JOIN matches$ M ON M.MATCH_ID = MS.MATCH_ID
JOIN stadiums$ S ON M.MATCH_ID = S.S_ID
GROUP BY S.S_ID, S.NAME, S.CITY, S.COUNTRY
ORDER BY Total_attendance DESC;

--Question No. 13
--The player duo with the greatest number of goal-assist combination (i.e. pair of players that have assisted each other in more goals than any other duo).
SELECT TOP 1 P.FIRST_NAME, P.LAST_NAME, P.PLAYER_ID ,CONCAT(gl1.PID, '-', gl2.ASSIST) AS PlayerDuo, COUNT(*) AS GoalAssistCombination
FROM goals$ AS gl1
JOIN goals$ AS gl2 ON gl1.ASSIST = gl2.PID AND gl1.MATCH_ID = gl2.MATCH_ID AND gl1.GOAL_DESC = gl2.GOAL_DESC
JOIN players$ P ON gl2.PID = P.PLAYER_ID
GROUP BY CONCAT(gl1.PID, '-', gl2.ASSIST), P.FIRST_NAME, P.LAST_NAME, P.PLAYER_ID
ORDER BY COUNT(*) DESC;

--Question No. 14
--The team having players with more header goal percentage than any other team in 2020.
SELECT teams$.ID,teams$.TEAM_NAME
FROM TEAM,

--Question No. 15
--The most successful manager of UCL (2016-2022).

